﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Info_Tools
{
    class Facturation_des_produits
    {
        #region Champs
        private string _produits_commande;
        private string _num_produits;
        private int _prix_produits;
        private int _num_facture;
        private int _nbr_pdts_commande;
        private int _datefact;
        #endregion

        #region Constructeurs
        public Facturation_des_produits(string pc, string nup, int pp, int nuf, int nb_pdts, int df)
        {
            _produits_commande = pc;
            _num_produits = nup;
            _prix_produits = pp;
            _num_facture = nuf;
            _nbr_pdts_commande = nb_pdts;
            _datefact = df;
        }
        #endregion
        public string Prod_commande
        {
            get { return _produits_commande; }
            set { _produits_commande = value; }
        }

        public string Num_produits
        {
            get { return _num_produits;  }
            set { _num_produits = value;  }
        }
        public int Prix_prod
        {
            get { return _prix_produits; }
            set { _prix_produits = value; }
        }

        public int Num_fac
        {
            get { return _num_facture; }
            set { _num_facture = value; }
        }

        public int Nb_pdts_commande
        {
            get { return _nbr_pdts_commande; }
            set { _nbr_pdts_commande = value; }
        }
        public int Date_fac
        {
            get { return _datefact; }
            set { _datefact = value; }
        }
    } 
}
