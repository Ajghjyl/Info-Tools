﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Info_Tools
{
    class clients
    {
        #region Champs
        private string _NomCli;
        private string _PreCli;
        private string _MailCli;
        private int _TelCli;
        private string _AdrCli;
        private string _VilleCli;
        private int _CpCli;
        private int _Prospect;
        #endregion

        #region Constructeurs

        public clients(string nc, string pc, string mc, int tc, string ad, string vc, int cp, int pr)
        {
            _NomCli = nc;
            _PreCli = pc;
            _MailCli = mc;
            _TelCli = tc;
            _AdrCli = ad;
            _VilleCli = vc;
            _CpCli = cp;
            _Prospect = pr;
        }
        #endregion
        public string NomCli
        {
            get { return _NomCli; }
            set { _NomCli = value; }
        }
        public string PreCli
        {
            get { return _PreCli; }
            set { _PreCli = value; }
        }
        public string MailCli
        {
            get { return _MailCli; }
            set { _MailCli = value; }
        }
        public int TelCli
        {
            get { return _TelCli; }
            set { _TelCli = value; }
        }
        public string AdrCli
        {
            get { return _AdrCli; }
            set { _AdrCli = value; }
        }
        public string VilleCli
        {
            get { return _VilleCli; }
            set { _VilleCli = value; }
        }
        public int CpCli
        {
            get { return _CpCli; }
            set { _CpCli = value; }
        }
        public int Prospect
        {
            get { return _Prospect; }
            set { _Prospect = value; }
        }
    }
}