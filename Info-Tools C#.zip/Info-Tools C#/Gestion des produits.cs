﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Info_Tools
{
    class Gestion_des_produits
    {
        #region Champs
        private string _nom_produits;
        private int _id_prod;
        private string _prix_produits;
        private string _descrip_prod;
        private string _type_prod;
        
        #endregion

        #region Constructeurs

        public Gestion_des_produits(string np, int idp, string pp, string dp, string tp)
        {
            _nom_produits = np;
            _id_prod = idp;
            _prix_produits = pp;
            _descrip_prod = dp;
            _type_prod = tp;
            
        }
        #endregion
        public string Nom_prod
        {
            get { return _nom_produits; }
            set { _nom_produits = value; }
        }
        public int Id_prod
        {
            get { return _id_prod; }
             set { _id_prod = value; }
        }
        public string Prix_prod1
        {
            get { return _prix_produits; }
            set { _prix_produits = value; }
        }
        public string Descrip_prod
        {
            get { return _descrip_prod; }
            set { _descrip_prod = value; }
        }
        public string Type_prod
        {
            get { return _type_prod; }
            set { _type_prod = value; }
        }
      
    }
}
