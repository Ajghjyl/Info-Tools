﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using MySql.Data.MySqlClient;

namespace Info_Tools
{
    /// <summary>
    /// Logique d'interaction pour MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<clients> client = new List<clients>();
        public MainWindow()
        {
            InitializeComponent();
        }

       /*private void Window_load (object sender, RoutedEventArgs e)
        {

           var query =
           from client in infotools 
           select new { Nom = client.NomCli, Prenom = client.PrenomCli, Mail = client.MailCli, Tel = client.NumCli, Ville = client.VilleCli, CP = client.CPCli };

            dtgClients.ItemsSource = query.ToList();
        }*/


        private void Rdv_clients_Click(object sender, RoutedEventArgs e)
        {

        }

        //datagrid récupère information client
        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            clients clientselected = (clients)dtgClients.SelectedItem;
        }
    }
}
