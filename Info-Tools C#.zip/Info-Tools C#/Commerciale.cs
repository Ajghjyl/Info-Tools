﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Info_Tools
{
    class Commerciaux
    {
        #region Champs
        private string _nom_Com;
        private string _pre_Com;
        private int _tel_Com;
        private string _mail_Com;
        private string _mdp_Com;
        #endregion

        #region Constructeurs

        public Commerciaux(string nom, string pre, int tel, string mail, string mdp)
        {
            _nom_Com = nom;
            _pre_Com = pre;
            _tel_Com = tel;
            _mail_Com = mail;
            _mdp_Com = mdp;
        }
        
        #endregion
        public string Nom_com
        {
            get { return _nom_Com; }
            set { _nom_Com = value; }
        }
        public string Pre_com
        {
            get { return _pre_Com; }
            set { _pre_Com = value; }
        }
        public int Tel_com
        {
            get { return _tel_Com; }
            set { _tel_Com = value; }
        }
        public string Mail_com
        {
            get { return _mail_Com; }
            set { _mail_Com = value; }
        }
        public string Mdp_com
        {
            get { return _mdp_Com; }
            set { _mdp_Com = value; }
        }
       
    }
}
