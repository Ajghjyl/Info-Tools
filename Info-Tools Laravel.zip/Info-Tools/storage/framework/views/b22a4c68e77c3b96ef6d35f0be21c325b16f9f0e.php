<?php $__env->startSection('title', $prospect->name . ' Activity'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card mt-3">
            <div class="card-body">
                <div class="d-flex">
                    <h1><?php echo e($prospect->name); ?> <small class="text-muted"><?php echo e(ucwords(str_replace('_', ' ', $activity->type))); ?></small></h1>
                    <div class="ml-auto">
                        <div class="dropdown">
                            <button class="btn btn-outline-secondary dropdown-toggle" type="button" id="triggerId" data-toggle="dropdown" aria-haspopup="true"
                                    aria-expanded="false">
                                        Actions
                                    </button>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="triggerId">
                                <a class="dropdown-item" href="<?php echo e(route('admin.prospects.activities.dashboard', $prospect)); ?>">View All Activities</a>
                                <a class="dropdown-item" href="<?php echo e(route('admin.prospects.prospect.dashboard', $prospect)); ?>">Prospect Dashboard</a>

                            </div>
                        </div>
                    </div>
                </div>

                <hr>

                <h5>Communication Type: <?php echo e(ucwords(str_replace('_', ' ', $activity->communication_type))); ?></h5>
                <h5>Notes:</h5>
                <p><?php echo e($activity->notes); ?></p>

                <h5 class="text-right"><small class="text-muted"><?php echo e($activity->created_at_pretty); ?></small></h5>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Info-Tools\resources\views/admin/prospects/activities/show.blade.php ENDPATH**/ ?>