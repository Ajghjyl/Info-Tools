﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Windows;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using iTextSharp.text;
using iTextSharp.text.pdf;

namespace Info_Tools
{
    /// <summary>
    /// Logique d'interaction pour MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void FormatPDF(object sender, RoutedEventArgs e)
        {
             GeneratePdf();
        }

        public void GeneratePdf()
        {
            //Nom du fichier
            string outFile = Environment.CurrentDirectory + "/Indicateur.pdf";
            //Création du document
            Document doc = new Document();
            //Ecrire le pdf
            PdfWriter.GetInstance(doc, new FileStream(outFile, FileMode.Create));
            //Travailler dedans
            doc.Open();

            //Palette de couleurs
            BaseColor blue = new BaseColor(0,75, 155);
            BaseColor grey = new BaseColor(240, 240, 240);
            BaseColor white = new BaseColor(255, 255, 255);

            // Polices d'écriture
            Font policeTitre = new Font(iTextSharp.text.Font.FontFamily.HELVETICA, 20f, iTextSharp.text.Font.BOLD, blue);

            Font policeTh = new Font(iTextSharp.text.Font.FontFamily.HELVETICA, 16f, iTextSharp.text.Font.BOLD, white);

            //Page
            //Création paragraphes
           Paragraph p1 = new Paragraph("Dernier graphique\n\n", policeTitre);
            p1.Alignment = Element.ALIGN_CENTER;
            doc.Add(p1);

            Paragraph p2 = new Paragraph("Client" + Client.Text, policeTitre);
            p2.Alignment = Element.ALIGN_LEFT;
            doc.Add(p2);

            Paragraph p3 = new Paragraph("Produit\n\n" + Produit.Text, policeTitre);
            p3.Alignment = Element.ALIGN_RIGHT;
            doc.Add(p3);
            //TODO: Ajouter vente produit dans un graphe

            // Fermer le document
            doc.Close();
            //Lancer le PDF
            Process.Start(@" cmd.exe ", @"/c" + outFile);
        }

        
    }
}
